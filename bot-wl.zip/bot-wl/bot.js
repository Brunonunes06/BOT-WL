// bot.js
require('dotenv').config();
const fs = require('fs-extra');
const path = require('path');
const { Client, GatewayIntentBits, Partials, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, InteractionType, PermissionsBitField } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID; // para registrar comandos no guild (mais rápido)
const LOG_CHANNEL_ID = process.env.LOG_CHANNEL_ID; // canal onde cai as aplicações
const APPROVER_ROLE_ID = process.env.APPROVER_ROLE_ID; // papel que pode aprovar/reprovar
const APPROVED_ROLE_ID = process.env.APPROVED_ROLE_ID; // papel que será dado quando aprovado

if (!TOKEN || !CLIENT_ID || !GUILD_ID || !LOG_CHANNEL_ID || !APPROVER_ROLE_ID || !APPROVED_ROLE_ID) {
  console.error('Configure DISCORD_TOKEN, CLIENT_ID, GUILD_ID, LOG_CHANNEL_ID, APPROVER_ROLE_ID, APPROVED_ROLE_ID no .env');
  process.exit(1);
}

const DATA_FILE = path.join(__dirname, 'whitelist.json');
fs.ensureFileSync(DATA_FILE);
if (!fs.readJsonSync(DATA_FILE, { throws: false })) fs.writeJsonSync(DATA_FILE, []);

const client = new Client({
  intents: [ GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers ],
  partials: [Partials.Channel]
});

// registra comandos de slash (no guild para testes rápidos)
async function registerCommands() {
  const commands = [
    {
      name: 'wl',
      description: 'Comandos de whitelist',
      options: [
        {
          name: 'iniciar',
          type: 1, // subcommand
          description: 'Inicia a aplicação (abre modal)'
        },
        {
          name: 'aprovar',
          type: 1,
          description: 'Aprova manualmente um usuário',
          options: [
            { name: 'usuario', type: 6, description: 'Usuário a aprovar', required: true },
            { name: 'motivo', type: 3, description: 'Motivo/opcional', required: false }
          ]
        },
        {
          name: 'reprovar',
          type: 1,
          description: 'Reprova manualmente um usuário',
          options: [
            { name: 'usuario', type: 6, description: 'Usuário a reprovar', required: true },
            { name: 'motivo', type: 3, description: 'Motivo/opcional', required: false }
          ]
        }
      ]
    }
  ];

  const rest = new REST({ version: '10' }).setToken(TOKEN);
  try {
    console.log('Registrando comandos no guild...');
    await rest.put(
      Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
      { body: commands }
    );
    console.log('Comandos registrados.');
  } catch (err) {
    console.error('Erro registrando comandos:', err);
  }
}

function readData() {
  return fs.readJsonSync(DATA_FILE, { throws: false }) || [];
}
function writeData(data) {
  fs.writeJsonSync(DATA_FILE, data, { spaces: 2 });
}

function createEntryObject(user, values) {
  return {
    id: Date.now().toString(), // id simples único
    userId: user.id,
    username: `${user.username}#${user.discriminator}`,
    submittedAt: new Date().toISOString(),
    status: 'pending',
    fields: values,
    handledBy: null,
    handledAt: null,
    note: null
  };
}

client.once('ready', async () => {
  console.log(`Logado como ${client.user.tag}`);
  await registerCommands();
});

client.on('interactionCreate', async (interaction) => {
  try {
    // Slash command group /wl
    if (interaction.isChatInputCommand()) {
      const sub = interaction.options.getSubcommand();
      if (sub === 'iniciar') {
        // abre modal
        const modal = new ModalBuilder()
          .setCustomId('wl_modal')
          .setTitle('Aplicação - Whitelist');

        const nomeInput = new TextInputBuilder()
          .setCustomId('nome')
          .setLabel('Nome (jogo/nome real)')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(100);

        const idadeInput = new TextInputBuilder()
          .setCustomId('idade')
          .setLabel('Idade')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(5);

        const expInput = new TextInputBuilder()
          .setCustomId('experiencia')
          .setLabel('Experiência no RP (resuma)')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000);

        const porqueInput = new TextInputBuilder()
          .setCustomId('porque')
          .setLabel('Por que deseja entrar nessa facção?')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000);

        modal.addComponents(
          new ActionRowBuilder().addComponents(nomeInput),
          new ActionRowBuilder().addComponents(idadeInput),
          new ActionRowBuilder().addComponents(expInput),
          new ActionRowBuilder().addComponents(porqueInput)
        );

        await interaction.showModal(modal);
        return;
      }

      if (sub === 'aprovar' || sub === 'reprovar') {
        // comando manual
        if (!interaction.member.roles.cache.has(APPROVER_ROLE_ID) && interaction.user.id !== interaction.guild.ownerId) {
          await interaction.reply({ content: 'Você não tem permissão para usar este comando.', ephemeral: true });
          return;
        }

        const target = interaction.options.getMember('usuario');
        const motivo = interaction.options.getString('motivo') || null;
        if (!target) {
          await interaction.reply({ content: 'Usuário não encontrado no servidor.', ephemeral: true });
          return;
        }

        const data = readData();
        const last = data.filter(e => e.userId === target.id).sort((a,b) => b.submittedAt.localeCompare(a.submittedAt))[0];

        if (!last) {
          await interaction.reply({ content: 'Não há aplicações desse usuário no registro.', ephemeral: true });
          return;
        }

        if (sub === 'aprovar') {
          if (last.status === 'approved') {
            await interaction.reply({ content: 'Aplicação já aprovada anteriormente.', ephemeral: true });
            return;
          }
          last.status = 'approved';
          last.handledBy = `${interaction.user.username}#${interaction.user.discriminator}`;
          last.handledAt = new Date().toISOString();
          last.note = motivo;
          writeData(data);

          // adiciona cargo
          try { await target.roles.add(APPROVED_ROLE_ID, `Aprovado por ${interaction.user.tag}`); } catch(e){ console.warn('Não foi possível adicionar cargo:', e.message); }

          const embed = new EmbedBuilder()
            .setTitle('Aplicação Aprovada (manual)')
            .setDescription(`Usuário: <@${target.id}>`)
            .addFields(
              { name: 'Aprovado por', value: `${interaction.user.tag}`, inline: true },
              { name: 'Motivo', value: motivo || 'Nenhum', inline: true },
              { name: 'Aplicação ID', value: last.id, inline: true }
            )
            .setTimestamp();

          const logCh = await client.channels.fetch(LOG_CHANNEL_ID).catch(()=>null);
          if (logCh && logCh.isTextBased()) logCh.send({ embeds: [embed] });

          await interaction.reply({ content: `Usuário ${target.user.tag} aprovado com sucesso.`, ephemeral: true });
        } else {
          // reprovar
          last.status = 'rejected';
          last.handledBy = `${interaction.user.username}#${interaction.user.discriminator}`;
          last.handledAt = new Date().toISOString();
          last.note = motivo;
          writeData(data);

          const embed = new EmbedBuilder()
            .setTitle('Aplicação Reprovada (manual)')
            .setDescription(`Usuário: <@${target.id}>`)
            .addFields(
              { name: 'Reprovado por', value: `${interaction.user.tag}`, inline: true },
              { name: 'Motivo', value: motivo || 'Nenhum', inline: true },
              { name: 'Aplicação ID', value: last.id, inline: true }
            )
            .setTimestamp();

          const logCh = await client.channels.fetch(LOG_CHANNEL_ID).catch(()=>null);
          if (logCh && logCh.isTextBased()) logCh.send({ embeds: [embed] });

          await interaction.reply({ content: `Usuário ${target.user.tag} reprovado.`, ephemeral: true });
        }

        return;
      }
    }

    // Modal submit
    if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'wl_modal') {
      await interaction.deferReply({ ephemeral: true });

      const nome = interaction.fields.getTextInputValue('nome');
      const idade = interaction.fields.getTextInputValue('idade');
      const experiencia = interaction.fields.getTextInputValue('experiencia');
      const porque = interaction.fields.getTextInputValue('porque');

      const entry = createEntryObject(interaction.user, { nome, idade, experiencia, porque });
      const data = readData();
      data.push(entry);
      writeData(data);

      // cria embed e botões no canal de logs
      const embed = new EmbedBuilder()
        .setTitle('Nova Aplicação de Whitelist')
        .setDescription(`Aplicante: <@${interaction.user.id}>`)
        .addFields(
          { name: 'Nome', value: nome || '—' },
          { name: 'Idade', value: idade || '—', inline: true },
          { name: 'Experiência', value: experiencia || '—' },
          { name: 'Por que quer entrar?', value: porque || '—' },
          { name: 'ID da aplicação', value: entry.id, inline: true }
        )
        .setFooter({ text: `User ID: ${interaction.user.id}` })
        .setTimestamp();

      const btnApprove = new ButtonBuilder()
        .setCustomId(`wl_approve_${entry.id}`)
        .setLabel('Aprovar')
        .setStyle(ButtonStyle.Success);

      const btnReject = new ButtonBuilder()
        .setCustomId(`wl_reject_${entry.id}`)
        .setLabel('Reprovar')
        .setStyle(ButtonStyle.Danger);

      const row = new ActionRowBuilder().addComponents(btnApprove, btnReject);

      const logCh = await client.channels.fetch(LOG_CHANNEL_ID).catch(()=>null);
      if (logCh && logCh.isTextBased()) {
        await logCh.send({ embeds: [embed], components: [row] });
      }

      await interaction.editReply({ content: 'Aplicação enviada com sucesso! Aguarde avaliação.', ephemeral: true });
      return;
    }

    // Buttons approve/reject
    if (interaction.isButton()) {
      const custom = interaction.customId;
      if (!custom.startsWith('wl_')) return;

      // check approver role
      const member = interaction.member;
      if (!member.roles.cache.has(APPROVER_ROLE_ID) && interaction.user.id !== interaction.guild.ownerId) {
        await interaction.reply({ content: 'Você não tem permissão para usar esse botão.', ephemeral: true });
        return;
      }

      const [ , action, entryId ] = custom.split('_'); // e.g. ['wl','approve','123']
      const data = readData();
      const entry = data.find(e => e.id === entryId);
      if (!entry) {
        await interaction.reply({ content: 'Aplicação não encontrada no registro.', ephemeral: true });
        return;
      }
      if (action === 'approve') {
        if (entry.status === 'approved') {
          await interaction.reply({ content: 'Aplicação já aprovada.', ephemeral: true });
          return;
        }
        entry.status = 'approved';
        entry.handledBy = `${interaction.user.username}#${interaction.user.discriminator}`;
        entry.handledAt = new Date().toISOString();
        writeData(data);

        // adiciona cargo
        const guildMember = await interaction.guild.members.fetch(entry.userId).catch(()=>null);
        if (guildMember) {
          try { await guildMember.roles.add(APPROVED_ROLE_ID, `Aprovado por ${interaction.user.tag}`); } catch(e){ console.warn('Erro ao adicionar cargo:', e.message); }
        }

        await interaction.update({ content: `Aplicação ${entry.id} aprovada por ${interaction.user.tag}.`, embeds: [], components: [] }).catch(()=>null);
        const embed = new EmbedBuilder().setTitle('Aplicação Aprovada').setDescription(`Aplicação ID: ${entry.id}\nUsuário: <@${entry.userId}>`).setTimestamp();
        const logCh = await client.channels.fetch(LOG_CHANNEL_ID).catch(()=>null);
        if (logCh && logCh.isTextBased()) logCh.send({ embeds: [embed] });

      } else if (action === 'reject') {
        if (entry.status === 'rejected') {
          await interaction.reply({ content: 'Aplicação já reprovada.', ephemeral: true });
          return;
        }
        entry.status = 'rejected';
        entry.handledBy = `${interaction.user.username}#${interaction.user.discriminator}`;
        entry.handledAt = new Date().toISOString();
        writeData(data);

        await interaction.update({ content: `Aplicação ${entry.id} reprovada por ${interaction.user.tag}.`, embeds: [], components: [] }).catch(()=>null);
        const embed = new EmbedBuilder().setTitle('Aplicação Reprovada').setDescription(`Aplicação ID: ${entry.id}\nUsuário: <@${entry.userId}>`).setTimestamp();
        const logCh = await client.channels.fetch(LOG_CHANNEL_ID).catch(()=>null);
        if (logCh && logCh.isTextBased()) logCh.send({ embeds: [embed] });
      } else {
        await interaction.reply({ content: 'Ação desconhecida.', ephemeral: true });
      }
      return;
    }
  } catch (err) {
    console.error('Erro em interactionCreate:', err);
    if (interaction && !interaction.replied) {
      try { await interaction.reply({ content: 'Ocorreu um erro ao processar sua ação.', ephemeral: true }); } catch {}
    }
  }
});



client.login(TOKEN);
