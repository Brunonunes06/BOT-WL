//---------------------------------------------------------
// BOT WL — SISTEMA PROFISSIONAL COMPLETO
//---------------------------------------------------------

const {
    Client, GatewayIntentBits, Events,
    ActionRowBuilder, ButtonBuilder, ButtonStyle,
    ModalBuilder, TextInputBuilder, TextInputStyle,
    EmbedBuilder
} = require("discord.js");
const fs = require("fs");

//---------------------------------------------------------
// CONFIGURAÇÕES
//---------------------------------------------------------

const TOKEN = "MTQ0NDM0OTA3NjQ2MzE1NzM0OA.GfzPqS.lyCqOvzhlj6cl3lvFCj5p_ZllgeGMo4GLBmTsk";

// Canais
const CANAL_FORM = "1443781902019330078";
const CANAL_LOGS = "1444693726172545056";

// Cargos WL
const ROLE_MEMBRO = "1442202003282333889";

// Permissões WL (quem pode aprovar e reprovar)
const PERMITIDOS = [
    "1442201993102758011", // Líder
    "1442201995225075895", // Sub Líder
    "1442201997460635780", // Resp Recrutador
    "1442214978441711648"  // Recrutador
];

//---------------------------------------------------------
// BANCO DE DADOS LOCAL
//---------------------------------------------------------

const dbFile = "wl.json";
if (!fs.existsSync(dbFile)) fs.writeFileSync(dbFile, "{}");

const loadDB = () => JSON.parse(fs.readFileSync(dbFile));
const saveDB = (data) => fs.writeFileSync(dbFile, JSON.stringify(data, null, 4));

//---------------------------------------------------------
// CLIENT
//---------------------------------------------------------

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers
    ]
});

//---------------------------------------------------------
// BOT ONLINE
//---------------------------------------------------------

client.once(Events.ClientReady, async () => {
    console.log(`🔥 BOT ONLINE COMO ${client.user.tag}`);

    try {
        const canal = await client.channels.fetch(CANAL_FORM);

        const botao = new ButtonBuilder()
            .setCustomId("abrirForm")
            .setLabel("📋 Abrir Formulário")
            .setStyle(ButtonStyle.Primary);

        await canal.send({
            embeds: [
                new EmbedBuilder()
                    .setTitle("📋 Formulário de Entrada")
                    .setDescription("Clique abaixo para abrir o formulário de cadastro.")
                    .setColor("#5865F2")
                    .setThumbnail("https://cdn-icons-png.flaticon.com/512/992/992700.png")
            ],
            components: [new ActionRowBuilder().addComponents(botao)]
        });

    } catch (e) {
        console.log("❌ Erro ao enviar mensagem inicial:", e);
    }
});

//---------------------------------------------------------
// INTERAÇÕES
//---------------------------------------------------------

client.on(Events.InteractionCreate, async interaction => {

    const guild = interaction.guild;
    const member = interaction.member;
    const logs = await client.channels.fetch(CANAL_LOGS).catch(() => null);

    //-----------------------------------------------------
    // 1️⃣ — ABRIR FORMULÁRIO
    //-----------------------------------------------------

    if (interaction.isButton() && interaction.customId === "abrirForm") {

        const modal = new ModalBuilder()
            .setCustomId("formEntrada")
            .setTitle("📋 Formulário de Entrada");

        const nome = new TextInputBuilder().setCustomId("nome").setLabel("Nome").setRequired(true).setStyle(TextInputStyle.Short);
        const id = new TextInputBuilder().setCustomId("id").setLabel("ID").setRequired(true).setStyle(TextInputStyle.Short);
        const tell = new TextInputBuilder().setCustomId("tell").setLabel("Tell").setRequired(true).setStyle(TextInputStyle.Short);
        const recrutador = new TextInputBuilder().setCustomId("recrutador").setLabel("Recrutador").setRequired(true).setStyle(TextInputStyle.Short);

        return interaction.showModal(
            modal.addComponents(
                new ActionRowBuilder().addComponents(nome),
                new ActionRowBuilder().addComponents(id),
                new ActionRowBuilder().addComponents(tell),
                new ActionRowBuilder().addComponents(recrutador)
            )
        );
    }

    //-----------------------------------------------------
    // 2️⃣ — RECEBER FORMULÁRIO
    //-----------------------------------------------------

    if (interaction.isModalSubmit() && interaction.customId === "formEntrada") {

        const nome = interaction.fields.getTextInputValue("nome");
        const id = interaction.fields.getTextInputValue("id");
        const tell = interaction.fields.getTextInputValue("tell");
        const recrutador = interaction.fields.getTextInputValue("recrutador");

        let db = loadDB();
        db[member.id] = { nome, id, tell, recrutador, status: "pendente" };
        saveDB(db);

        //-----------------------------------------------------
        // Remove formulário anterior do mesmo usuário
        //-----------------------------------------------------

        if (logs) {
            const mensagens = await logs.messages.fetch({ limit: 50 }).catch(() => []);

            mensagens
                .filter(msg =>
                    msg.embeds.length > 0 &&
                    msg.embeds[0].data.fields &&
                    msg.embeds[0].data.fields.some(f => f.value === `<@${member.id}>`)
                )
                .forEach(msg => msg.delete().catch(() => {}));
        }

        //-----------------------------------------------------
        // EMBED PROFISSIONAL
        //-----------------------------------------------------

        const embed = new EmbedBuilder()
            .setTitle("📄 Formulário Recebido")
            .setThumbnail(member.displayAvatarURL())
            .addFields(
                { name: "👤 Usuário:", value: `<@${member.id}>` },
                { name: "📍 Nome", value: nome, inline: true },
                { name: "🆔 ID", value: id, inline: true },
                { name: "📞 Tell", value: tell, inline: true },
                { name: "🤝 Recrutador", value: recrutador }
            )
            .setColor("#2F3136")
            .setFooter({ text: `Hoje às ${new Date().toLocaleTimeString("pt-BR")}` });

        //-----------------------------------------------------
        // BOTÕES APROVAR/REPROVAR
        //-----------------------------------------------------

        const aprovarBtn = new ButtonBuilder()
            .setCustomId(`aprovar_${member.id}`)
            .setLabel("✔ Aprovar")
            .setStyle(ButtonStyle.Success);

        const reprovarBtn = new ButtonBuilder()
            .setCustomId(`reprovar_${member.id}`)
            .setLabel("✘ Reprovar")
            .setStyle(ButtonStyle.Danger);

        logs.send({
            embeds: [embed],
            components: [new ActionRowBuilder().addComponents(aprovarBtn, reprovarBtn)]
        });

        interaction.reply({
            content: "📨 **Formulário enviado com sucesso!**",
            ephemeral: true
        });
    }

    //-----------------------------------------------------
    // 3️⃣ — APROVAR WL
    //-----------------------------------------------------

    if (interaction.isButton() && interaction.customId.startsWith("aprovar_")) {

        const pode = PERMITIDOS.some(role => member.roles.cache.has(role));
        if (!pode)
            return interaction.reply({ content: "❌ Você não tem permissão!", ephemeral: true });

        const alvoID = interaction.customId.split("_")[1];
        const dados = loadDB()[alvoID];

        const alvo = await guild.members.fetch(alvoID).catch(() => null);
        if (!alvo)
            return interaction.reply({ content: "❌ Usuário não encontrado.", ephemeral: true });

        await alvo.setNickname(`${dados.nome} | ${dados.id}`).catch(()=>{});
        await alvo.roles.add(ROLE_MEMBRO).catch(()=>{});

        interaction.reply({
            content: `🟩 WL de <@${alvoID}> aprovada!`,
            ephemeral: true
        });
    }

    //-----------------------------------------------------
    // 4️⃣ — REPROVAR WL
    //-----------------------------------------------------

    if (interaction.isButton() && interaction.customId.startsWith("reprovar_")) {

        const pode = PERMITIDOS.some(role => member.roles.cache.has(role));
        if (!pode)
            return interaction.reply({ content: "❌ Você não tem permissão!", ephemeral: true });

        const alvoID = interaction.customId.split("_")[1];
        const alvo = await guild.members.fetch(alvoID).catch(() => null);

        if (!alvo)
            return interaction.reply({ content: "❌ Usuário não encontrado.", ephemeral: true });

        const cargosRemoviveis = alvo.roles.cache.filter(role =>
            role.id !== guild.id &&
            role.position < guild.members.me.roles.highest.position
        );

        await alvo.roles.remove(cargosRemoviveis).catch(() => {});

        interaction.reply({
            content: `🟥 WL de <@${alvoID}> reprovada. Todos os cargos removidos.`,
            ephemeral: true
        });
    }
});

//---------------------------------------------------------
// LOGIN
//---------------------------------------------------------

client.login(TOKEN);
